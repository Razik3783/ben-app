import React from "react";
import ReactDOM from "react-dom/client";
import BenApp from "./App";
import "./index.css";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <BenApp />
  </React.StrictMode>
);
